<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>user::editor::Plugin</name>
    <message>
        <source>ID_USEREDITOR_VIEW_INDICATORVIEW_NAME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID_USEREDITOR_VIEW_INDICATORVIEW_DESCRIPTION</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
