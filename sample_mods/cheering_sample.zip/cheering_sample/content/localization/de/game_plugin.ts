<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>user::Plugin</name>
    <message>
        <source>ID_USER_COMPONENT_INDICATOR_NAME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID_USER_COMPONENT_INDICATOR_DESCRIPTION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID_USER_COMPONENT_INDICATOR_COLOR_DESCRIPTION</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
