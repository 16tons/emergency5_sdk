/*
 The zlib/libpng License
 
 Copyright (c) 2005-2007 Phillip Castaneda (pjcast -- www.wreckedgames.com)
 
 This software is provided 'as-is', without any express or implied warranty. In no event will
 the authors be held liable for any damages arising from the use of this software.
 
 Permission is granted to anyone to use this software for any purpose, including commercial
 applications, and to alter it and redistribute it freely, subject to the following
 restrictions:
 
 1. The origin of this software must not be misrepresented; you must not claim that
 you wrote the original software. If you use this software in a product,
 an acknowledgment in the product documentation would be appreciated but is
 not required.
 
 2. Altered source versions must be plainly marked as such, and must not be
 misrepresented as being the original software.
 
 3. This notice may not be removed or altered from any source distribution.
 */

#include "mac/CocoaInputManager.h"
#include "mac/CocoaKeyboard.h"
#include "mac/CocoaMouse.h"
#include "mac/MacHIDManager.h"
#include "OISException.h"

namespace OIS
{
	//--------------------------------------------------------------------------------//
	CocoaInputManager::CocoaInputManager() :
		InputManager("Mac OS X Cocoa Input Manager"),
		mView(nullptr),
		mHideMouse(true),
		mGrabMouse(true),
		mUseRepeat(false),
		mKeyboardUsed(false),
		mMouseUsed(false)
	{
		//Setup our internal factories
		mFactories.push_back(this);

		mHIDManager = new MacHIDManager();
		mFactories.push_back(mHIDManager);
	}

	//--------------------------------------------------------------------------------//
	CocoaInputManager::~CocoaInputManager()
	{
		delete mHIDManager;
	}

	//--------------------------------------------------------------------------------//
	void CocoaInputManager::_initialize(ParamList &paramList)
	{
		_parseConfigSettings(paramList);

		//Enumerate all devices attached
		_enumerateDevices();

		mHIDManager->initialize();
	}

	//--------------------------------------------------------------------------------//
	void CocoaInputManager::_parseConfigSettings(ParamList &paramList)
	{
		// We might receive a NSWindow or a NSView pointer here, or even nothing
		ParamList::iterator i = paramList.find("WINDOW");
		if(i != paramList.end())
		{
			id windowPtr = reinterpret_cast<id>(strtoul(i->second.c_str(), 0, 10));
			if (nullptr != windowPtr)
			{
				if ([windowPtr isKindOfClass:[NSWindow class]])
				{
					NSWindow* window = reinterpret_cast<NSWindow*>(windowPtr);
					mView = [window contentView];
				}
				else if ([windowPtr isKindOfClass:[NSView class]])
				{
					mView = reinterpret_cast<NSView*>(windowPtr);
				}
				else
				{
					OIS_EXCEPT(E_General, "CocoaInputManager::_parseConfigSettings >> Provided window pointer is neither a NSWindow nor a NSView");
				}
			}
		}
		else
		{
			// else get the main active window.. user might not have access to it through some
			// graphics libraries, if that fails then try at the application level.
			NSWindow* window = [[NSApplication sharedApplication] keyWindow];
			if (nullptr != window)
			{
				mView = [window contentView];
			}
		}

		if(mView == nullptr)
		{
			OIS_EXCEPT(E_General, "CocoaInputManager::_parseConfigSettings >> Unable to find a window or event target");
		}

		// Keyboard
		if(paramList.find("MacAutoRepeatOn") != paramList.end())
		{
			if(paramList.find("MacAutoRepeatOn")->second == "true")
			{
				mUseRepeat = true;
			}
		}

		// Mouse
		if(paramList.find("cocoa_noMouseGrab") != paramList.end())
		{
			if(paramList.find("cocoa_noMouseGrab")->second == "true")
			{
				mGrabMouse = false;
			}
		}
		if(paramList.find("cocoa_noMouseHide") != paramList.end())
		{
			if(paramList.find("cocoa_noMouseHide")->second == "true")
			{
				mHideMouse = false;
			}
		}
	}

	//--------------------------------------------------------------------------------//
	void CocoaInputManager::_enumerateDevices()
	{
		// Nothing to do in here
	}

	//--------------------------------------------------------------------------------//
	DeviceList CocoaInputManager::freeDeviceList()
	{
		DeviceList ret;

		if(mKeyboardUsed == false)
		{
			ret.insert(std::make_pair(OISKeyboard, mInputSystemName));
		}

		if(mMouseUsed == false)
		{
			ret.insert(std::make_pair(OISMouse, mInputSystemName));
		}

		return ret;
	}

	//--------------------------------------------------------------------------------//
	int CocoaInputManager::totalDevices(Type iType)
	{
		switch(iType)
		{
			case OISKeyboard:
				return 1;

			case OISMouse:
				return 1;

			default:
				return 0;
		}
	}

	//--------------------------------------------------------------------------------//
	int CocoaInputManager::freeDevices(Type iType)
	{
		switch(iType)
		{
			case OISKeyboard:
				return mKeyboardUsed ? 0 : 1;

			case OISMouse:
				return mMouseUsed ? 0 : 1;

			default:
				return 0;
		}
	}

	//--------------------------------------------------------------------------------//
	bool CocoaInputManager::vendorExist(Type iType, const std::string& vendor)
	{
		return ((iType == OISKeyboard || iType == OISMouse) && vendor == mInputSystemName);
	}

	//--------------------------------------------------------------------------------//
	Object* CocoaInputManager::createObject(InputManager* creator, Type iType, bool bufferMode, const std::string& vendor)
	{
		Object *obj = nullptr;

		switch(iType)
		{
			case OISKeyboard:
			{
				if(mKeyboardUsed == false)
				{
					obj = new CocoaKeyboard(this, bufferMode, mUseRepeat);
				}
				break;
			}

			case OISMouse:
			{
				if(mMouseUsed == false)
				{
					obj = new CocoaMouse(this, bufferMode, mHideMouse, mGrabMouse);
				}
				break;
			}

			default:
			{
				obj = mHIDManager->createObject(creator, iType, bufferMode, vendor);
				break;
			}
		}

		if(obj == nullptr)
		{
			OIS_EXCEPT(E_InputDeviceNonExistant, "No devices match requested type.");
		}

		return obj;
	}

	//--------------------------------------------------------------------------------//
	void CocoaInputManager::destroyObject(Object* obj)
	{
		delete obj;
	}
}
