/*
 The zlib/libpng License
 
 Copyright (c) 2005-2007 Phillip Castaneda (pjcast -- www.wreckedgames.com)
 
 This software is provided 'as-is', without any express or implied warranty. In no event will
 the authors be held liable for any damages arising from the use of this software.
 
 Permission is granted to anyone to use this software for any purpose, including commercial
 applications, and to alter it and redistribute it freely, subject to the following
 restrictions:
 
 1. The origin of this software must not be misrepresented; you must not claim that
 you wrote the original software. If you use this software in a product,
 an acknowledgment in the product documentation would be appreciated but is
 not required.
 
 2. Altered source versions must be plainly marked as such, and must not be
 misrepresented as being the original software.
 
 3. This notice may not be removed or altered from any source distribution.
 */
#include "mac/CocoaMouse.h"
#include "mac/CocoaInputManager.h"
#include "mac/CocoaHelpers.h"
#include "OISException.h"
#include "OISEvents.h"

namespace OIS
{
	//-------------------------------------------------------------------//
	CocoaMouse::CocoaMouse(InputManager* creator, bool buffered, bool hideMouse, bool grabMouse) :
		Mouse(creator->inputSystemName(), buffered, 0, creator)
	{
		@autoreleasepool
		{
			CocoaInputManager* man = static_cast<CocoaInputManager*>(mCreator);

			NSView* windowContentView = man->_getView();
			if(nullptr != windowContentView)
			{
				mResponder = [[CocoaMouseView alloc] initWithFrame:[windowContentView frame]];
				if(nullptr != mResponder)
				{
					[mResponder setOISMouseObj:this];
					[mResponder setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];

					[windowContentView setAutoresizesSubviews:YES];
					[windowContentView addSubview:mResponder];

					if(grabMouse)
					{
						[mResponder grabMouse];
					}

					if(hideMouse)
					{
						[mResponder hideMouse];
					}

					man->_setMouseUsed(true);
				}
				else
				{
					OIS_EXCEPT(E_General, "CocoaMouseView::CocoaMouseView >> Error creating event responder");
				}
			}
			else
			{
				OIS_EXCEPT(E_General, "CocoaMouseView::CocoaMouseView >> Error creating event responder");
			}
		}
	}

	CocoaMouse::~CocoaMouse()
	{
		if(nullptr != mResponder)
		{
			@autoreleasepool
			{
				[mResponder setOISMouseObj:nil];
				[mResponder release];
				mResponder = nullptr;
			}
		}

		static_cast<CocoaInputManager*>(mCreator)->_setMouseUsed(false);
	}

	void CocoaMouse::_initialize()
	{
		mState.clear();
	}

	void CocoaMouse::setBuffered( bool buffered )
	{
		mBuffered = buffered;
	}

	void CocoaMouse::capture()
	{
		[mResponder capture];
	}

	// Use NSTrackingArea to track mouse move events
	const NSTrackingAreaOptions trackingOptions = NSTrackingMouseMoved | NSTrackingEnabledDuringMouseDrag | NSTrackingMouseEnteredAndExited | NSTrackingActiveInKeyWindow | NSTrackingInVisibleRect;
}

@implementation CocoaMouseView

- (id)initWithFrame:(NSRect)frame
{
	self = [super initWithFrame:frame];
	if(self)
	{
		mTempState.clear();
		mNeedsToRegainFocus = true;
		mMouseGrab = false;
		mMouseHide = false;
		mTrackingArea = nullptr;
	}
	return self;
}

- (void)viewDidMoveToWindow
{
	if (nullptr != mTrackingArea);
	{
		[self removeTrackingArea:mTrackingArea];
		[mTrackingArea release];
		mTrackingArea = nullptr;
	}

	NSWindow* window = [self window];
	if(nullptr != window)
	{
		mTrackingArea = [[NSTrackingArea alloc] initWithRect:[self bounds] options:OIS::trackingOptions owner:self userInfo:nil];
		[self addTrackingArea:mTrackingArea];

		[window setAcceptsMouseMovedEvents:YES];
	}
}

- (BOOL)acceptsFirstMouse:(NSEvent *)theEvent
{
	return YES;
}

- (void)setOISMouseObj:(OIS::CocoaMouse *)obj
{
	oisMouseObj = obj;
}

- (void)grabMouse
{
	mMouseGrab = true;

	if (!mNeedsToRegainFocus)
	{
		NSRect frame = [self frame];
		NSRect warpPoint = NSMakeRect(frame.size.width / 2 + frame.origin.x, frame.size.height / 2 + frame.origin.y, 1, 1);
		NSPoint absoluteWarpPoint = [[self window] convertRectToScreen:warpPoint].origin;

		CGPoint absoluteCarbonWarpPoint = CGPointMake(absoluteWarpPoint.x, NSMaxY([NSScreen mainScreen].frame) - absoluteWarpPoint.y);

		CGDisplayMoveCursorToPoint(kCGDirectMainDisplay, absoluteCarbonWarpPoint);

		CGAssociateMouseAndMouseCursorPosition(false);
	}
}

- (void)hideMouse
{
	mMouseHide = true;

	if (!mNeedsToRegainFocus)
	{
		CGDisplayHideCursor(kCGDirectMainDisplay);
	}
}

- (void)capture
{
	OIS::MouseState *state = oisMouseObj->getMouseStatePtr();
	state->X.rel = 0;
	state->Y.rel = 0;
	state->Z.rel = 0;
	
	if(mTempState.X.rel || mTempState.Y.rel || mTempState.Z.rel)
	{
		// Set new relative motion values
		state->X.rel = mTempState.X.rel;
		state->Y.rel = mTempState.Y.rel;
		state->Z.rel = mTempState.Z.rel;

		{ // Update absolute position
			// The default OIS implementation is keeping an absolute value which is incrementally updated. This is dangerous and easily leads to invalid values.
			// state->X.abs += mTempState.X.rel;
			// state->Y.abs += mTempState.Y.rel;
			// state->Z.abs += mTempState.Z.rel;

			// Ask the OS about the current relative mouse position to be on the safe side
			NSWindow* window = [self window];
			NSPoint pos = [window mouseLocationOutsideOfEventStream];
			NSRect frame = [[window contentView] frame];

			// Cocoa's coordinate system has the origin in the bottom left so we need to transform the height
			state->X.abs = pos.x;
			state->Y.abs = frame.size.height - pos.y;
			state->Z.abs += mTempState.Z.rel;
		}

		// Clip the absolute X coordinate
		if(state->X.abs > state->width)
		{
			state->X.abs = state->width;
		}
		else if(state->X.abs < 0)
		{
			state->X.abs = 0;
		}
		
		// Clip the absolute Y coordinate
		if(state->Y.abs > state->height)
		{
			state->Y.abs = state->height;
		}
		else if(state->Y.abs < 0)
		{
			state->Y.abs = 0;
		}
		
		//Fire off event
		if(oisMouseObj->buffered() && oisMouseObj->getEventCallback())
		{
			oisMouseObj->getEventCallback()->mouseMoved(OIS::MouseEvent(oisMouseObj, *state));
		}
	}
	
	mTempState.clear();
}

#pragma mark Left Mouse Event overrides
- (void)mouseDown:(NSEvent *)theEvent
{
	if (nil != oisMouseObj)
	{
		int mouseButton = OIS::MB_Left;
		NSEventType type = [theEvent type];
		OIS::MouseState *state = oisMouseObj->getMouseStatePtr();

		if(type == NSLeftMouseDown && ([theEvent modifierFlags] & NSAlternateKeyMask))
		{
			mouseButton = OIS::MB_Middle;
		}
		else if(type == NSLeftMouseDown && ([theEvent modifierFlags] & NSControlKeyMask))
		{
			mouseButton = OIS::MB_Right;
		}
		else if(type == NSLeftMouseDown)
		{
			mouseButton = OIS::MB_Left;
		}

		state->buttons |= 1 << mouseButton;

		if(oisMouseObj->buffered() && oisMouseObj->getEventCallback())
		{
			oisMouseObj->getEventCallback()->mousePressed(OIS::MouseEvent(oisMouseObj, *state), (OIS::MouseButtonID)mouseButton);
		}
	}

	[super mouseDown:theEvent];
}

- (void)mouseUp:(NSEvent *)theEvent
{
	if (nil != oisMouseObj)
	{
		int mouseButton = OIS::MB_Left;
		NSEventType type = [theEvent type];
		OIS::MouseState *state = oisMouseObj->getMouseStatePtr();

		if((type == NSLeftMouseUp) && ([theEvent modifierFlags] & NSAlternateKeyMask))
		{
			mouseButton = OIS::MB_Middle;
		}
		else if((type == NSLeftMouseUp) && ([theEvent modifierFlags] & NSControlKeyMask))
		{
			mouseButton = OIS::MB_Right;
		}
		else if(type == NSLeftMouseUp)
		{
			mouseButton = OIS::MB_Left;
		}

		state->buttons &= ~(1 << mouseButton);

		if(oisMouseObj->buffered() && oisMouseObj->getEventCallback())
		{
			oisMouseObj->getEventCallback()->mouseReleased(OIS::MouseEvent(oisMouseObj, *state), (OIS::MouseButtonID)mouseButton);
		}
	}

	[super mouseUp:theEvent];
}


- (void)mouseDragged:(NSEvent *)theEvent
{
	// Relative positioning
	mTempState.X.rel += [theEvent deltaX];
	mTempState.Y.rel += [theEvent deltaY];

	[super mouseDragged:theEvent];
}

#pragma mark Right Mouse Event overrides
- (void)rightMouseDown:(NSEvent *)theEvent
{
	if (nil != oisMouseObj)
	{
		int mouseButton = OIS::MB_Right;
		NSEventType type = [theEvent type];
		OIS::MouseState *state = oisMouseObj->getMouseStatePtr();
	
		if(type == NSRightMouseDown)
		{
			state->buttons |= 1 << mouseButton;
		}

		if(oisMouseObj->buffered() && oisMouseObj->getEventCallback())
		{
			oisMouseObj->getEventCallback()->mousePressed(OIS::MouseEvent(oisMouseObj, *state), (OIS::MouseButtonID)mouseButton);
		}
	}

	[super rightMouseDown:theEvent];
}

- (void)rightMouseUp:(NSEvent *)theEvent
{
	if (nil != oisMouseObj)
	{
		int mouseButton = OIS::MB_Right;
		NSEventType type = [theEvent type];
		OIS::MouseState *state = oisMouseObj->getMouseStatePtr();
	
		if(type == NSRightMouseUp)
		{
			state->buttons &= ~(1 << mouseButton);
		}

		if(oisMouseObj->buffered() && oisMouseObj->getEventCallback())
		{
			oisMouseObj->getEventCallback()->mouseReleased(OIS::MouseEvent(oisMouseObj, *state), (OIS::MouseButtonID)mouseButton);
		}
	}

	[super rightMouseUp:theEvent];
}

- (void)rightMouseDragged:(NSEvent *)theEvent
{
	// Relative positioning
	mTempState.X.rel += [theEvent deltaX];
	mTempState.Y.rel += [theEvent deltaY];

	[super rightMouseDragged:theEvent];
}

#pragma mark Other Mouse Event overrides
- (void)otherMouseDown:(NSEvent *)theEvent
{
	if (nil != oisMouseObj)
	{
		int mouseButton = OIS::MB_Middle;
		NSEventType type = [theEvent type];
		OIS::MouseState *state = oisMouseObj->getMouseStatePtr();
	
		if(type == NSOtherMouseDown)
		{
			state->buttons |= 1 << mouseButton;
		}

		if(oisMouseObj->buffered() && oisMouseObj->getEventCallback())
		{
			oisMouseObj->getEventCallback()->mousePressed(OIS::MouseEvent(oisMouseObj, *state), (OIS::MouseButtonID)mouseButton);
		}
	}

	[super otherMouseDown:theEvent];
}

- (void)otherMouseUp:(NSEvent *)theEvent
{
	if (nil != oisMouseObj)
	{
		int mouseButton = OIS::MB_Middle;
		NSEventType type = [theEvent type];
		OIS::MouseState *state = oisMouseObj->getMouseStatePtr();
	
		if(type == NSOtherMouseUp)
		{
			state->buttons &= ~(1 << mouseButton);
		}

		if(oisMouseObj->buffered() && oisMouseObj->getEventCallback())
		{
			oisMouseObj->getEventCallback()->mouseReleased(OIS::MouseEvent(oisMouseObj, *state), (OIS::MouseButtonID)mouseButton);
		}
	}

	[super otherMouseUp:theEvent];
}

- (void)otherMouseDragged:(NSEvent *)theEvent
{
	// Relative positioning
	mTempState.X.rel += [theEvent deltaX];
	mTempState.Y.rel += [theEvent deltaY];

	[super otherMouseDragged:theEvent];
}

- (void)scrollWheel:(NSEvent *)theEvent
{
	if([theEvent deltaY] != 0.0)
	{
		mTempState.Z.rel += ([theEvent deltaY] * 60);
	}

	[super scrollWheel:theEvent];
}

- (void)mouseMoved:(NSEvent *)theEvent
{
	// Relative positioning
	mTempState.X.rel += [theEvent deltaX];
	mTempState.Y.rel += [theEvent deltaY];

	[super mouseMoved:theEvent];
}

- (void)mouseEntered:(NSEvent *)theEvent
{
	if (mNeedsToRegainFocus && nil != oisMouseObj)
	{
		if (mMouseHide)
		{
			CGDisplayHideCursor(kCGDirectMainDisplay);
		}

		if (mMouseGrab)
		{
			CGAssociateMouseAndMouseCursorPosition(false);
		}
		else
		{
			NSWindow* window = [self window];
			NSPoint pos = [window mouseLocationOutsideOfEventStream];
			NSRect frame = [[window contentView] frame];

			// Clear the previous mouse state
			OIS::MouseState *state = oisMouseObj->getMouseStatePtr();
			state->clear();

			// Cocoa's coordinate system has the origin in the bottom left so we need to transform the height
			mTempState.X.rel = pos.x;
			mTempState.Y.rel = frame.size.height - pos.y;
		}

		mNeedsToRegainFocus = false;
	}

	[super mouseEntered:theEvent];
}

- (void)mouseExited:(NSEvent *)theEvent
{
	if (!mNeedsToRegainFocus)
	{
		mNeedsToRegainFocus = true;

		if (mMouseHide)
		{
			CGDisplayShowCursor(kCGDirectMainDisplay);
		}

		if (mMouseGrab)
		{
			CGAssociateMouseAndMouseCursorPosition(true);
		}
	}

	[super mouseExited:theEvent];
}

@end
