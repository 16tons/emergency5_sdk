// SortUtils.h

#ifndef __SORTUTLS_H
#define __SORTUTLS_H

#include "Common/MyString.h"

void SortFileNames(const UStringVector &strings, CIntVector &indices);

#endif
