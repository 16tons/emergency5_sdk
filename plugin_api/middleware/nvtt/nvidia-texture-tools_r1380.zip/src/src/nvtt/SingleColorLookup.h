
#include "nvcore/nvcore.h" // uint8

extern uint8 OMatch5[256][2];
extern uint8 OMatch6[256][2];
extern uint8 OMatchAlpha5[256][2];
extern uint8 OMatchAlpha6[256][2];

void initSingleColorLookup();